// Listen for window messages from the page
window.addEventListener("message", function(event) {
    // Optionally, you can verify the event origin here if needed
    if (event.source !== window) return;
  
    if (event.data && event.data.action === "block") {
      // Use a default duration of 25 minutes if not provided.
      const duration = event.data.duration ? event.data.duration : 25;
      chrome.runtime.sendMessage({ action: "startBlocking", duration: duration }, (response) => {
        console.log("Content script: Block message forwarded to background.", response);
      });
    } else if (event.data && event.data.action === "unblock") {
      chrome.runtime.sendMessage({ action: "stopBlocking" }, (response) => {
        console.log("Content script: Unblock message forwarded to background.", response);
      });
    }
  });
  