// Use a unique ID for your dynamic rule
const BLOCK_RULE_ID = 100;

// Listen for messages from the content script (or directly from the page)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "startBlocking") {
    const duration = message.duration; // duration in minutes

    // Define a dynamic rule that blocks all top-level navigations,
    // except for allowed (learning) domains.
    const rule = {
      "id": BLOCK_RULE_ID,
      "priority": 1,
      "action": { "type": "block" },
      "condition": {
        "urlFilter": "*",
        "resourceTypes": ["main_frame"],
        "excludedRequestDomains": [
          "learnbite.com",
          "www.learnbite.com",
          "sinanneedtocode.github.io"
          // You can add additional allowed domains here
        ]
      }
    };

    // Add the dynamic blocking rule
    chrome.declarativeNetRequest.updateDynamicRules({
      addRules: [rule],
      removeRuleIds: [] // Remove existing rules with this ID, if any
    }, () => {
      console.log("Websites are now blocked (dynamic rule added).");
      sendResponse({ status: "blocking started", duration: duration });
    });

    // Set a timer to remove the blocking rule after the given duration (in minutes)
    setTimeout(() => {
      chrome.declarativeNetRequest.updateDynamicRules({
        addRules: [],
        removeRuleIds: [BLOCK_RULE_ID]
      }, () => {
        console.log("Timer finished – websites are now unblocked.");
      });
    }, duration * 60 * 1000);

    // Return true to indicate an asynchronous response.
    return true;
  } else if (message.action === "stopBlocking") {
    // Remove the blocking rule immediately.
    chrome.declarativeNetRequest.updateDynamicRules({
      addRules: [],
      removeRuleIds: [BLOCK_RULE_ID]
    }, () => {
      console.log("Blocking rule manually removed.");
      sendResponse({ status: "blocking stopped" });
    });
    return true;
  }
});
